/**
 * Student.java
 * Represents a single student with all relevant attributes.
 * Demonstrates encapsulation using private fields and public getters/setters.
 */
public class Student {

    // ── Private Fields (encapsulation) ──────────────────────────────────────
    private String studentId;
    private String name;
    private int    age;
    private String grade;          // e.g. "10", "11", "12"
    private String email;
    private String phone;
    private String address;

    // ── Constructor ─────────────────────────────────────────────────────────
    /**
     * Creates a fully initialised Student object.
     *
     * @param studentId Unique identifier  (e.g. "STU001")
     * @param name      Full name
     * @param age       Age in years  (must be > 0)
     * @param grade     Grade/class   (e.g. "10A")
     * @param email     Contact e-mail
     * @param phone     Contact phone number
     * @param address   Home address
     */
    public Student(String studentId, String name, int age,
                   String grade, String email, String phone, String address) {
        this.studentId = studentId;
        this.name      = name;
        this.age       = age;
        this.grade     = grade;
        this.email     = email;
        this.phone     = phone;
        this.address   = address;
    }

    // ── Getters ─────────────────────────────────────────────────────────────
    public String getStudentId() { return studentId; }
    public String getName()      { return name; }
    public int    getAge()       { return age; }
    public String getGrade()     { return grade; }
    public String getEmail()     { return email; }
    public String getPhone()     { return phone; }
    public String getAddress()   { return address; }

    // ── Setters ─────────────────────────────────────────────────────────────
    public void setName(String name)       { this.name    = name; }
    public void setAge(int age)            { this.age     = age; }
    public void setGrade(String grade)     { this.grade   = grade; }
    public void setEmail(String email)     { this.email   = email; }
    public void setPhone(String phone)     { this.phone   = phone; }
    public void setAddress(String address) { this.address = address; }

    // ── Formatted Display ────────────────────────────────────────────────────
    /**
     * Returns a neatly formatted multi-line summary of the student.
     */
    @Override
    public String toString() {
        String line = "─".repeat(50);
        return String.format(
            "\n%s\n" +
            "  %-15s : %s\n" +
            "  %-15s : %s\n" +
            "  %-15s : %d\n" +
            "  %-15s : %s\n" +
            "  %-15s : %s\n" +
            "  %-15s : %s\n" +
            "  %-15s : %s\n" +
            "%s",
            line,
            "Student ID",  studentId,
            "Name",        name,
            "Age",         age,
            "Grade",       grade,
            "Email",       email,
            "Phone",       phone,
            "Address",     address,
            line
        );
    }

    /**
     * Returns a compact single-line summary for table listings.
     */
    public String toTableRow() {
        return String.format("| %-8s | %-20s | %-3d | %-5s | %-25s |",
            studentId, name, age, grade, email);
    }
}
