# User Guide — Student Information System

## Starting the Program

Run `StudentInformationSystem`. You will see the main menu:

```
╔══════════════════════════════════════════╗
║     STUDENT INFORMATION SYSTEM  v1.0     ║
║          Built with Java  ☕              ║
╚══════════════════════════════════════════╝

┌─────────────────────────────────────┐
│              MAIN MENU               │
├─────────────────────────────────────┤
│  1.  Add    Student                  │
│  2.  View   All Students             │
│  3.  Search Student                  │
│  4.  Update Student                  │
│  5.  Delete Student                  │
│  6.  Exit                            │
└─────────────────────────────────────┘
Enter choice (1-6):
```

Five sample students are preloaded so you can explore immediately.

---

## Adding a Student (Option 1)

Enter each field when prompted. The system will re-ask until valid input is given.

```
Enter full name          : John O'Brien
Enter age (3 – 25)      : 15
Enter grade (K, 1-12…)  : 10A
Enter email             : john@school.com
Enter phone (10 digits) : 9876543210
Enter address           : 88 Park Street, Mumbai
```

The new record is displayed with its auto-assigned ID (e.g. `STU006`).

---

## Viewing All Students (Option 2)

Prints a compact table:

```
+----------+----------------------+-----+-------+---------------------------+
| ID       | Name                 | Age | Grade | Email                     |
+----------+----------------------+-----+-------+---------------------------+
| STU001   | Aarav Sharma         |  16 | 11A   | aarav.sharma@example.com  |
...
```

---

## Searching (Option 3)

- **By ID**: type the full ID, e.g. `STU003` → returns that student's details.
- **By Name**: type any part of a name, e.g. `patel` → returns all matches.

---

## Updating a Student (Option 4)

1. Enter the student ID.
2. Pick the field to change (1–6).
3. Enter the new value — validation applies.

---

## Deleting a Student (Option 5)

1. Enter the student ID.
2. Confirm with `yes` (anything else cancels).

---

## Error Messages

| Message                           | Cause                               |
|-----------------------------------|-------------------------------------|
| Name must contain only letters …  | Digits or special chars in name     |
| Age must be between 3 – 25        | Out-of-range or non-numeric age     |
| Invalid grade                     | Grade not in the accepted list      |
| Invalid email format              | Missing @ or domain                 |
| Phone must be 10 digits           | Wrong length or invalid characters  |
| Student not found                 | ID doesn't exist in the system      |
