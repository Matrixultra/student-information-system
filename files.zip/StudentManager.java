import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * StudentManager.java
 * Handles all business logic: add, view, update, delete, and search.
 * Uses an ArrayList as the in-memory data store.
 */
public class StudentManager {

    // In-memory store (acts like a mini database)
    private final ArrayList<Student> students = new ArrayList<>();

    // Auto-increment ID counter — starts at 1
    private int idCounter = 1;

    // ── Constructor: load sample data ────────────────────────────────────────
    public StudentManager() {
        loadSampleData();
    }

    // ── ID Generation ────────────────────────────────────────────────────────

    /** Generates the next unique student ID in the format STU001, STU002, … */
    public String generateId() {
        return String.format("STU%03d", idCounter++);
    }

    // ── CREATE ───────────────────────────────────────────────────────────────

    /**
     * Adds a new Student to the list.
     *
     * @param student A fully validated Student object
     * @return true on success (always in this version)
     */
    public boolean addStudent(Student student) {
        students.add(student);
        System.out.println("\n  ✔  Student \"" + student.getName()
                           + "\" added successfully (ID: " + student.getStudentId() + ")");
        return true;
    }

    // ── READ ─────────────────────────────────────────────────────────────────

    /** Returns all students as an unmodifiable view. */
    public List<Student> getAllStudents() {
        return students;
    }

    /** Prints a formatted table of all students. */
    public void displayAllStudents() {
        if (students.isEmpty()) {
            System.out.println("\n  No students in the system yet.");
            return;
        }

        String header = String.format(
            "+----------+----------------------+-----+-------+---------------------------+%n" +
            "| ID       | Name                 | Age | Grade | Email                     |%n" +
            "+----------+----------------------+-----+-------+---------------------------+"
        );
        System.out.println("\n" + header);
        for (Student s : students) {
            System.out.println(s.toTableRow());
        }
        System.out.println("+----------+----------------------+-----+-------+---------------------------+");
        System.out.println("  Total students: " + students.size());
    }

    /** Prints the full details of a single student. */
    public void displayStudent(Student s) {
        if (s != null) System.out.println(s);
    }

    // ── SEARCH ───────────────────────────────────────────────────────────────

    /**
     * Finds a student by their exact ID (case-insensitive).
     *
     * @return matching Student, or null if not found
     */
    public Student findById(String id) {
        for (Student s : students) {
            if (s.getStudentId().equalsIgnoreCase(id.trim())) return s;
        }
        return null;
    }

    /**
     * Finds all students whose names contain the search term (case-insensitive).
     *
     * @return list of matching students (may be empty)
     */
    public List<Student> findByName(String name) {
        String term = name.trim().toLowerCase();
        return students.stream()
            .filter(s -> s.getName().toLowerCase().contains(term))
            .collect(Collectors.toList());
    }

    // ── UPDATE ───────────────────────────────────────────────────────────────

    /**
     * Replaces the name on an existing student record.
     *
     * @return true if the student was found and updated
     */
    public boolean updateName(String id, String newName) {
        Student s = findById(id);
        if (s == null) return false;
        s.setName(newName);
        return true;
    }

    public boolean updateAge(String id, int newAge) {
        Student s = findById(id);
        if (s == null) return false;
        s.setAge(newAge);
        return true;
    }

    public boolean updateGrade(String id, String newGrade) {
        Student s = findById(id);
        if (s == null) return false;
        s.setGrade(newGrade);
        return true;
    }

    public boolean updateEmail(String id, String newEmail) {
        Student s = findById(id);
        if (s == null) return false;
        s.setEmail(newEmail);
        return true;
    }

    public boolean updatePhone(String id, String newPhone) {
        Student s = findById(id);
        if (s == null) return false;
        s.setPhone(newPhone);
        return true;
    }

    public boolean updateAddress(String id, String newAddress) {
        Student s = findById(id);
        if (s == null) return false;
        s.setAddress(newAddress);
        return true;
    }

    // ── DELETE ───────────────────────────────────────────────────────────────

    /**
     * Removes the student with the given ID.
     *
     * @return true if a student was removed, false if not found
     */
    public boolean deleteStudent(String id) {
        Student s = findById(id);
        if (s == null) return false;
        students.remove(s);
        System.out.println("\n  ✔  Student \"" + s.getName() + "\" removed successfully.");
        return true;
    }

    // ── Utility ───────────────────────────────────────────────────────────────

    public int getTotalCount() {
        return students.size();
    }

    // ── Sample Data ──────────────────────────────────────────────────────────

    /**
     * Pre-loads five students so the system is not empty on first launch.
     */
    private void loadSampleData() {
        students.add(new Student(generateId(), "Aarav Sharma",   16, "11A",
            "aarav.sharma@example.com",   "9876543210", "12 MG Road, Bengaluru"));
        students.add(new Student(generateId(), "Priya Nair",     14, "9B",
            "priya.nair@example.com",     "9123456780", "45 Indiranagar, Bengaluru"));
        students.add(new Student(generateId(), "Rohan Mehta",    17, "12A",
            "rohan.mehta@example.com",    "9988776655", "7 Koramangala, Bengaluru"));
        students.add(new Student(generateId(), "Sneha Reddy",    15, "10B",
            "sneha.reddy@example.com",    "9871234560", "22 HSR Layout, Bengaluru"));
        students.add(new Student(generateId(), "Arjun Patel",    13, "8A",
            "arjun.patel@example.com",    "9765432100", "5 Whitefield, Bengaluru"));
    }
}
