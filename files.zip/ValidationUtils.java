/**
 * ValidationUtils.java
 * Centralised validation methods reused across the whole application.
 * All methods are static — no need to instantiate this class.
 */
public class ValidationUtils {

    // Valid grades accepted by the system (Grades 1–12 + Kindergarten)
    private static final String[] VALID_GRADES = {
        "K","1","2","3","4","5","6","7","8","9","10","11","12",
        "1A","1B","2A","2B","3A","3B","4A","4B","5A","5B",
        "6A","6B","7A","7B","8A","8B","9A","9B",
        "10A","10B","11A","11B","12A","12B"
    };

    private static final int MIN_AGE = 3;
    private static final int MAX_AGE = 25;

    // ── Age ─────────────────────────────────────────────────────────────────

    /**
     * Returns true when age is between MIN_AGE and MAX_AGE (inclusive).
     */
    public static boolean isValidAge(int age) {
        return age >= MIN_AGE && age <= MAX_AGE;
    }

    /**
     * Tries to parse a String as an integer and validates the range.
     *
     * @return parsed age, or -1 if the input is not a valid integer / out of range
     */
    public static int parseAndValidateAge(String input) {
        try {
            int age = Integer.parseInt(input.trim());
            return isValidAge(age) ? age : -1;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    // ── Grade ────────────────────────────────────────────────────────────────

    /**
     * Returns true when the supplied grade string is in the accepted list.
     * Comparison is case-insensitive.
     */
    public static boolean isValidGrade(String grade) {
        if (grade == null || grade.isBlank()) return false;
        for (String valid : VALID_GRADES) {
            if (valid.equalsIgnoreCase(grade.trim())) return true;
        }
        return false;
    }

    // ── Name ─────────────────────────────────────────────────────────────────

    /**
     * A name is valid when it is non-blank and contains only letters, spaces,
     * hyphens, and apostrophes (e.g. "O'Brien", "Mary-Jane").
     */
    public static boolean isValidName(String name) {
        return name != null
            && !name.isBlank()
            && name.trim().matches("[a-zA-Z '\\-]+");
    }

    // ── Email ────────────────────────────────────────────────────────────────

    /**
     * Basic e-mail format check.
     */
    public static boolean isValidEmail(String email) {
        return email != null
            && email.trim().matches("^[\\w._%+\\-]+@[\\w.\\-]+\\.[a-zA-Z]{2,}$");
    }

    // ── Phone ────────────────────────────────────────────────────────────────

    /**
     * Accepts 10-digit numbers, optionally prefixed with + and a country code
     * (up to 3 digits).  Examples: 9876543210, +919876543210.
     */
    public static boolean isValidPhone(String phone) {
        return phone != null
            && phone.trim().matches("^(\\+\\d{1,3})?\\d{10}$");
    }

    // ── Student ID ───────────────────────────────────────────────────────────

    /**
     * Student IDs must match the pattern STU followed by 3 digits, e.g. STU042.
     */
    public static boolean isValidStudentId(String id) {
        return id != null && id.trim().matches("STU\\d{3}");
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    /** Prints a clear, formatted validation error message. */
    public static void printError(String message) {
        System.out.println("\n  ⚠  ERROR: " + message);
    }

    /** Returns a human-readable list of accepted grade values. */
    public static String validGradeList() {
        return "K, 1-12 (optionally followed by A or B, e.g. 10A)";
    }

    /** Returns the age range description. */
    public static String ageRange() {
        return MIN_AGE + " – " + MAX_AGE;
    }
}
