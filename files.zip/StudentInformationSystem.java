import java.util.List;
import java.util.Scanner;

/**
 * StudentInformationSystem.java
 * Entry point — runs the menu-driven console interface.
 *
 * Compile:  javac src/*.java -d out/
 * Run:      java -cp out StudentInformationSystem
 */
public class StudentInformationSystem {

    private static final Scanner scanner = new Scanner(System.in);
    private static final StudentManager manager = new StudentManager();

    // ══════════════════════════════════════════════════════════════════════════
    //  MAIN
    // ══════════════════════════════════════════════════════════════════════════
    public static void main(String[] args) {
        printBanner();

        boolean running = true;
        while (running) {
            printMainMenu();
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1" -> addStudentFlow();
                case "2" -> viewAllStudents();
                case "3" -> searchStudentFlow();
                case "4" -> updateStudentFlow();
                case "5" -> deleteStudentFlow();
                case "6" -> {
                    System.out.println("\n  Goodbye! 👋\n");
                    running = false;
                }
                default  -> System.out.println("\n  ⚠  Invalid choice. Please enter 1–6.");
            }
        }
        scanner.close();
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  MENUS
    // ══════════════════════════════════════════════════════════════════════════

    private static void printBanner() {
        System.out.println("""
            ╔══════════════════════════════════════════╗
            ║     STUDENT INFORMATION SYSTEM  v1.0     ║
            ║          Built with Java  ☕              ║
            ╚══════════════════════════════════════════╝
            """);
    }

    private static void printMainMenu() {
        System.out.println("""
            
            ┌─────────────────────────────────────┐
            │              MAIN MENU               │
            ├─────────────────────────────────────┤
            │  1.  Add    Student                  │
            │  2.  View   All Students             │
            │  3.  Search Student                  │
            │  4.  Update Student                  │
            │  5.  Delete Student                  │
            │  6.  Exit                            │
            └─────────────────────────────────────┘
            Enter choice (1-6): \
            """);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  1. ADD STUDENT
    // ══════════════════════════════════════════════════════════════════════════

    private static void addStudentFlow() {
        System.out.println("\n  ── ADD NEW STUDENT ─────────────────────────────");

        // Name
        String name = promptValidName("  Enter full name          : ");

        // Age
        int age = promptValidAge("  Enter age (" + ValidationUtils.ageRange() + ")   : ");

        // Grade
        String grade = promptValidGrade("  Enter grade (" + ValidationUtils.validGradeList() + "): ");

        // Email
        String email = promptValidEmail("  Enter email              : ");

        // Phone
        String phone = promptValidPhone("  Enter phone (10 digits)  : ");

        // Address (free text – no special validation)
        System.out.print("  Enter address             : ");
        String address = scanner.nextLine().trim();

        // Build and persist
        String id = manager.generateId();
        Student student = new Student(id, name, age, grade, email, phone, address);
        manager.addStudent(student);
        System.out.println(student);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  2. VIEW ALL
    // ══════════════════════════════════════════════════════════════════════════

    private static void viewAllStudents() {
        System.out.println("\n  ── ALL STUDENTS ────────────────────────────────");
        manager.displayAllStudents();
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  3. SEARCH
    // ══════════════════════════════════════════════════════════════════════════

    private static void searchStudentFlow() {
        System.out.println("""
            
              ── SEARCH ──────────────────────────────────────
              1. Search by Student ID
              2. Search by Name
              Enter choice: \
            """);

        String choice = scanner.nextLine().trim();

        switch (choice) {
            case "1" -> {
                System.out.print("  Enter Student ID (e.g. STU001): ");
                String id = scanner.nextLine().trim();
                Student found = manager.findById(id);
                if (found == null) System.out.println("\n  No student found with ID: " + id);
                else manager.displayStudent(found);
            }
            case "2" -> {
                System.out.print("  Enter name (or part of name): ");
                String name = scanner.nextLine().trim();
                List<Student> results = manager.findByName(name);
                if (results.isEmpty()) {
                    System.out.println("\n  No students found matching: \"" + name + "\"");
                } else {
                    System.out.println("\n  Found " + results.size() + " result(s):");
                    results.forEach(manager::displayStudent);
                }
            }
            default -> System.out.println("\n  ⚠  Invalid choice.");
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  4. UPDATE
    // ══════════════════════════════════════════════════════════════════════════

    private static void updateStudentFlow() {
        System.out.println("\n  ── UPDATE STUDENT ──────────────────────────────");
        System.out.print("  Enter Student ID to update: ");
        String id = scanner.nextLine().trim();

        Student s = manager.findById(id);
        if (s == null) {
            System.out.println("\n  ⚠  Student not found: " + id);
            return;
        }

        System.out.println("  Found student: " + s.getName());
        System.out.println("""
            
              What would you like to update?
              1. Name       4. Email
              2. Age        5. Phone
              3. Grade      6. Address
              Enter choice: \
            """);

        String choice = scanner.nextLine().trim();
        boolean ok = false;

        switch (choice) {
            case "1" -> {
                String name = promptValidName("  New name: ");
                ok = manager.updateName(id, name);
            }
            case "2" -> {
                int age = promptValidAge("  New age: ");
                ok = manager.updateAge(id, age);
            }
            case "3" -> {
                String grade = promptValidGrade("  New grade: ");
                ok = manager.updateGrade(id, grade);
            }
            case "4" -> {
                String email = promptValidEmail("  New email: ");
                ok = manager.updateEmail(id, email);
            }
            case "5" -> {
                String phone = promptValidPhone("  New phone: ");
                ok = manager.updatePhone(id, phone);
            }
            case "6" -> {
                System.out.print("  New address: ");
                String address = scanner.nextLine().trim();
                ok = manager.updateAddress(id, address);
            }
            default -> System.out.println("\n  ⚠  Invalid choice.");
        }

        if (ok) {
            System.out.println("\n  ✔  Record updated successfully.");
            manager.displayStudent(manager.findById(id));
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  5. DELETE
    // ══════════════════════════════════════════════════════════════════════════

    private static void deleteStudentFlow() {
        System.out.println("\n  ── DELETE STUDENT ──────────────────────────────");
        System.out.print("  Enter Student ID to delete: ");
        String id = scanner.nextLine().trim();

        Student s = manager.findById(id);
        if (s == null) {
            System.out.println("\n  ⚠  Student not found: " + id);
            return;
        }

        System.out.print("  Confirm delete \"" + s.getName() + "\"? (yes/no): ");
        String confirm = scanner.nextLine().trim();

        if (confirm.equalsIgnoreCase("yes")) {
            manager.deleteStudent(id);
        } else {
            System.out.println("\n  Delete cancelled.");
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  VALIDATED INPUT HELPERS
    // ══════════════════════════════════════════════════════════════════════════

    /** Keeps asking until a valid name is entered. */
    private static String promptValidName(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine();
            if (ValidationUtils.isValidName(input)) return input.trim();
            ValidationUtils.printError("Name must contain only letters, spaces, hyphens, or apostrophes.");
        }
    }

    /** Keeps asking until a valid age is entered. */
    private static int promptValidAge(String prompt) {
        while (true) {
            System.out.print(prompt);
            int age = ValidationUtils.parseAndValidateAge(scanner.nextLine());
            if (age != -1) return age;
            ValidationUtils.printError("Age must be a whole number between " + ValidationUtils.ageRange() + ".");
        }
    }

    /** Keeps asking until a valid grade is entered. */
    private static String promptValidGrade(String prompt) {
        while (true) {
            System.out.print(prompt);
            String grade = scanner.nextLine();
            if (ValidationUtils.isValidGrade(grade)) return grade.trim().toUpperCase();
            ValidationUtils.printError("Invalid grade. Accepted values: " + ValidationUtils.validGradeList());
        }
    }

    /** Keeps asking until a valid email is entered. */
    private static String promptValidEmail(String prompt) {
        while (true) {
            System.out.print(prompt);
            String email = scanner.nextLine();
            if (ValidationUtils.isValidEmail(email)) return email.trim();
            ValidationUtils.printError("Invalid email format. Example: student@school.com");
        }
    }

    /** Keeps asking until a valid phone is entered. */
    private static String promptValidPhone(String prompt) {
        while (true) {
            System.out.print(prompt);
            String phone = scanner.nextLine();
            if (ValidationUtils.isValidPhone(phone)) return phone.trim();
            ValidationUtils.printError("Phone must be 10 digits, optionally preceded by + and country code.");
        }
    }
}
